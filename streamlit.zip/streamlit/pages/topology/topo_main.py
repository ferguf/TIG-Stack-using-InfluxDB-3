import streamlit as st
from pages.topology import map1
import uuid

def run_topology_dashboard():
    # 1. State Management
    if "active_topology_id" not in st.session_state:
        st.session_state["active_topology_id"] = f"T-{str(uuid.uuid4())[:4].upper()}"
    
    topo_id = st.session_state["active_topology_id"]

    # 2. Global Header
    st.title("👥 Topology Dashboard")
    st.caption(f"Session: {topo_id}")

    # 3. Tab Routing
    t1, t2, t3, t4 = st.tabs(["👥 Gateway", "🚀 Metro", "🔗 AWS", "👁️ Route Vision"])

    with t1:
        map1.show_gateway(topo_id)

    with t2:
        map1.show_topology(topo_id)

if __name__ == "__main__":
    st.set_page_config(page_title="Network Map", layout="wide")
    run_topology_dashboard()