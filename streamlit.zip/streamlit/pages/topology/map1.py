import streamlit as st
from src.galileo.svg_galileo import render_galileo

def show_gateway(topology_id):
    st.subheader(f"🌐 Gateway Settings for {topology_id}")
    if "gateway_label" not in st.session_state:
        st.session_state["gateway_label"] = f"GW-{topology_id}"
    st.text_input("Gateway Label", key="gateway_label")

import streamlit as st
from src.galileo.svg_galileo import render_galileo

def show_topology(topology_id):
    st.subheader("🚀 Metro Network Map")
    
    # 1. Initialize the variable to None to avoid UnboundLocalError
    svg_str = None 
    
    label = st.session_state.get("gateway_label", topology_id)

    # 2. Prepare Data
    nodes = {
        0: {"radius": 0, "angle": 0, "label_header": label},
        1: {"radius": 160, "angle": 45, "label_header": "Site-A"},
        2: {"radius": 160, "angle": 180, "label_header": "Site-B"},
        3: {"radius": 280, "angle": 315, "label_header": "Cloud-Hub"},
    }
    links = [{"source": 0, "target": 1}, {"source": 0, "target": 2}, {"source": 0, "target": 3}]

    # 3. Try to generate the SVG
    try:
        svg_str = render_galileo(nodes, [], links)
    except Exception as e:
        st.error(f"Engine failed to run: {e}")

    # 4. Render only if svg_str was successfully assigned
    if svg_str:
        # Check length for debugging
        st.write(f"SVG Length: {len(svg_str)}")
        
        # 2025-compliant: Replaces use_container_width=True
        st.image(svg_str, width='stretch')
    else:
        st.warning("No SVG was generated. Check terminal for import errors.")