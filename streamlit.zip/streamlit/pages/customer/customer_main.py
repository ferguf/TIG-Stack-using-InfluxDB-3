import streamlit as st

# 1. Standard Imports (Top Level)
from src.api_client import get_customers
from src.ui_messages import MessageCenter
import pages.customer.service as service
import pages.customer.fabric_service as fab_serv

def run_customer_dashboard():
    # 1. State
    if "active_customer_id" not in st.session_state:
        st.session_state["active_customer_id"] = None
    
    # 2. Data Load
    if "customer_df" not in st.session_state:
        st.session_state["customer_df"] = get_customers()

    # 3. Header
    name = st.session_state.get("active_customer_name")
    st.title(f"👥 Selected: {name}" if name else "👥 Customer Dashboard")

    # 4. Tabs
    t1, t2, t3, t4 = st.tabs(["👥 Customers", "🔌 Fabric", "🔗 Connections", "👁️ Vision"])

    with t1:
        service.show_customers()

    with t2:
        active_id = st.session_state.get("active_customer_id")
        if active_id:
            fab_serv.show_fabric_service(active_id)
        else:
            st.warning("⚠️ Please select a Customer in the first tab.")

if __name__ == "__main__":
    run_customer_dashboard()