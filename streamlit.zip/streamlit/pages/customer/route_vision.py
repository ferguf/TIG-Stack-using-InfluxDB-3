import streamlit as st

def show_services():
    st.header("Route Visio powered by Galileo Vision")
    st.write("Visualize you Fabric service, Fabric Connection and Fabric Ports ...")
    # Add your logic here


