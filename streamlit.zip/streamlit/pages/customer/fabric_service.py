import streamlit as st
import pandas as pd
from src.state_managers import FabricStateManager
from src.api_client import (
    delete_fabric_service, 
    post_fabric_service, 
    get_fabric_services, 
    update_fabric_service
)
from src.ui_forms import create_fabric_service_form,update_fabric_service_form
from src.ui_components import UI
from src.ui_messages import MessageCenter



# --- 1. MAIN PAGE VIEWS ---

def render_provisioning_view(customer_id):
    """View shown when no fabric service is selected."""
    st.subheader("🚀 Create a new Fabric Service")
    
    if not st.session_state.get("fab_show_provision"):
        # Initial launcher button
        if UI.button("➕ Provision New Service", color="green", key="btn_open_prov_form"):
            st.session_state["fab_show_provision"] = True
            st.rerun()
    else:
        # Call the new container-style form
        form_data = create_fabric_service_form()
        
        if form_data:
            form_data["customer_id"] = customer_id
            try:
                post_fabric_service(form_data)
                MessageCenter.set_success(f"✅ Provisioning initiated for {form_data['service_name']}")
                st.session_state["fab_show_provision"] = False
                st.rerun()
            except Exception as e:
                st.error(f"Provisioning Failed: {e}")


def render_management_view(record):
    """
    Shows actions and forms for the selected fabric service.
    Uses UI.button with the specific color_map keys defined in your class.
    """
    if not record:
        return

    sid = record.get("service_id")
    service_name = record.get('service_name', 'Unnamed Service')
    
    st.info(f"📍 Context: **{service_name}**")
    
    col1, col2, _ = st.columns([1, 1, 4])
    
    with col1:
        # Changed 'orange' to 'amber' to match your UI.button color_map
        if UI.button("🔄 Change", color="amber", key=f"btn_upd_{sid}"):
            st.session_state["fab_show_update"] = True
            st.session_state["fab_confirm_delete"] = False
            st.rerun()

    with col2:
        if UI.button("🗑️ Delete", color="red", key=f"btn_del_{sid}"):
            st.session_state["fab_confirm_delete"] = True
            st.session_state["fab_show_update"] = False
            st.rerun()

    # --- Update Section ---
    if st.session_state.get("fab_show_update"):
        st.divider()
        updated_data = update_fabric_service_form(record) # From ui_forms.py
        
        if updated_data:
            try:
                # Merge original record with new data for the PUT request
                payload = {**record, **updated_data}
                payload.pop("Select", None) 
                
                update_fabric_service(sid, payload)
                MessageCenter.set_success(f"✅ {service_name} updated.")
                st.session_state["fab_show_update"] = False
                st.rerun()
            except Exception as e:
                st.error(f"Update failed: {e}")

    # --- Delete Section ---
    if st.session_state.get("fab_confirm_delete"):
        st.divider()
        with st.container(border=True):
            st.error(f"⚠️ Confirm Delete: **{service_name}**?")
            c1, c2, _ = st.columns([1.5, 1, 2])
            
            with c1:
                if UI.button("Yes, Delete", color="red", key=f"conf_del_{sid}"):
                    try:
                        delete_fabric_service(sid)
                        MessageCenter.set_success("🗑️ Service removed.")
                        st.session_state["fs_active_id"] = None
                        st.session_state["fs_active_record"] = None
                        st.session_state["fab_confirm_delete"] = False
                        st.rerun()
                    except Exception as e:
                        st.error(f"Deletion failed: {e}")
            with c2:
                if UI.button("Cancel", color="blue", key=f"can_del_{sid}"):
                    st.session_state["fab_confirm_delete"] = False
                    st.rerun()
# --- 2. MAIN ENTRY POINT ---

def show_fabric_service(customer_id):
    FabricStateManager.initialize()
    MessageCenter.display_messages()

    # 1. Fetch Data
    df = get_fabric_services(customer_id)

    # 2. Render Table (Handles empty df internally and returns None if no click)
    selection = UI.render_selectable_table(
        df=df, 
        key_prefix=f"fab_v12_{customer_id}", # Unique key per customer
        id_column_to_hide="service_id"
    )

    # 3. Sync (Will clear active_record if selection is None)
    if FabricStateManager.sync_selection(selection):
        st.rerun()

    # 4. Branching Logic
    active_record = FabricStateManager.get_active_record()
    
    st.divider()

    if df.empty or not active_record:
        # This now shows correctly if the table is empty OR just not clicked
        render_provisioning_view(customer_id)
    else:
        render_management_view(active_record)