import streamlit as st
import pandas as pd
from src.api_client import post_customer, update_customer, get_customers, delete_customer
from src.ui_components import UI
from src.ui_forms import create_customer_form, update_customer_form
from src.ui_messages import MessageCenter

# --- NAMESPACED STATE MANAGER ---
# We treat Customer as the "Primary" selection that drives the other tabs
class CustomerStateManager:
    @staticmethod
    def initialize():
        keys = {
            "cust_show_create": False,
            "cust_show_update": False,
            "cust_confirm_delete": False,
            "active_customer_id": None,
            "active_customer_name": None,
            "customer_df": None
        }
        for key, default in keys.items():
            if key not in st.session_state:
                st.session_state[key] = default

# --- DATA FETCHING ---

def sync_data():
    """Refreshes the customer dataframe in session state."""
    st.session_state["customer_df"] = get_customers()

def get_current_data():
    """Ensures data is loaded and returns it."""
    df = st.session_state.get("customer_df")
    if df is None or (isinstance(df, pd.DataFrame) and df.empty):
        sync_data()
        return st.session_state.get("customer_df")
    return df

# --- 2. ACTION HANDLERS ---

def handle_create():
    """Logic for adding a new customer."""
    if not st.session_state.get("cust_show_create"):
        if UI.button("➕ New Customer", color="green", key="btn_new_cust"):
            st.session_state["cust_show_create"] = True
            st.rerun()
    else:
        data = create_customer_form()
        if data:
            try:
                post_customer(data["customer_name"], data["account_id"])
                sync_data()
                MessageCenter.set_success(f"✅ Created {data['customer_name']}")
                st.session_state["cust_show_create"] = False
                st.rerun()
            except Exception as e:
                st.error(f"Creation Error: {e}")

def handle_update_delete(record):
    """Logic for modifying an existing customer."""
    rec_id = record["customer_id"]
    st.info(f"📍 Context: **{record.get('customer_name')}**")
    
    col1, col2, _ = st.columns([1, 1, 4])
    with col1:
        if UI.button("🔄 Update", color="amber", key=f"btn_upd_cust_{rec_id}"):
            st.session_state["cust_show_update"] = True
            st.session_state["cust_confirm_delete"] = False
            st.rerun()
    with col2:
        if UI.button("🗑️ Delete", color="red", key=f"btn_del_cust_{rec_id}"):
            st.session_state["cust_confirm_delete"] = True
            st.session_state["cust_show_update"] = False
            st.rerun()

    if st.session_state.get("cust_show_update"):
        _render_update_subform(record)
    
    if st.session_state.get("cust_confirm_delete"):
        _render_delete_confirmation(record)

# --- 3. PRIVATE UI SUB-COMPONENTS ---

def _render_update_subform(record):
    st.divider()
    updated = update_customer_form(record)
    if updated:
        update_customer(record["customer_id"], record["account_id"], updated["customer_name"])
        sync_data()
        MessageCenter.set_success("✅ Updated!")
        st.session_state["cust_show_update"] = False
        st.rerun()

def _render_delete_confirmation(record):
    st.divider()
    with st.container(border=True):
        st.error(f"Confirm Deletion of **{record['customer_name']}**?")
        c1, c2, _ = st.columns([1, 1, 2])
        if c1.button("❌ Cancel", key=f"can_cust_{record['customer_id']}"):
            st.session_state["cust_confirm_delete"] = False
            st.rerun()
        if c2.button("🗑️ Yes, Delete", key=f"conf_cust_{record['customer_id']}"):
            delete_customer(record["customer_id"])
            sync_data()
            st.session_state["cust_confirm_delete"] = False
            # Clear selection since customer is gone
            st.session_state["active_customer_id"] = None
            st.rerun()

# --- 4. MAIN ENTRY POINT ---

def show_customers():
    # 1. Initialize namespaced state
    CustomerStateManager.initialize()
    MessageCenter.display_messages()
    
    # 2. Fetch data
    df = get_current_data()
    
    # 3. Render Table - Defaulting to NO selection
    # Returns None if no row is clicked
    selection = UI.render_selectable_table(
        df=df, 
        key_prefix="main_cust_v1", 
        id_column_to_hide="customer_id"
    )

    # 4. Sync Global Selection (Safe Null Handling)
    new_id = selection.get("customer_id") if selection else None
    old_id = st.session_state.get("active_customer_id")

    if new_id != old_id:
        st.session_state["active_customer_id"] = new_id
        st.session_state["active_customer_name"] = selection.get("customer_name") if selection else None
        
        # Reset customer-specific UI toggles
        st.session_state["cust_show_update"] = False
        st.session_state["cust_confirm_delete"] = False
        
        # IMPORTANT: When the customer changes, we MUST clear the Fabric selection
        # so the Fabric tab doesn't show a record from the previous customer.
        st.session_state["fs_active_id"] = None
        st.session_state["fs_active_record"] = None
        
        st.rerun()

    st.divider()

    # 5. Flow Control
    # If the table is empty OR no row is selected, show Create Form
    if df is None or df.empty or not selection:
        handle_create()
    else:
        # Pass the specific selected record to the management view
        handle_update_delete(selection)