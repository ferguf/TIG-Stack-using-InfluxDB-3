import streamlit as st

st.set_page_config(layout="wide", page_title="Route Vision")

# We point to the main.py files within your subdirectories
pg = st.navigation({
    "Management": [
        st.Page("pages/customer/customer_main.py", title="Customer Center", icon="👥"),
    ],
    "Network": [
        st.Page("pages/topology/topo_main.py", title="Topology Explorer", icon="🌐"),
    ]
})

pg.run()