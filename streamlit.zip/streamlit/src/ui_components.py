import streamlit as st
import pandas as pd
from streamlit_extras.stylable_container import stylable_container
# -----------------------------
# Customer Table Renderer
# -----------------------------
def render_customer_table(df):
    if df is None or df.empty:
        st.info("No customer data available.")
        return None

    # We remove selection_mode to stop the crash
    # and use a checkbox column instead for compatibility.
    df_with_sel = df.copy()
    df_with_sel.insert(0, "Select", False)

    # Use a dynamic key to prevent state collision
    data_hash = hash(pd.util.hash_pandas_object(df).sum())

    event = st.data_editor(
        df_with_sel,
        key=f"cust_table_{data_hash}",
        use_container_width=True,
        hide_index=True,
        column_config={
            "Select": st.column_config.CheckboxColumn(
                "Select",
                help="Select a customer to edit",
                default=False,
            ),
            "customer_id": None # Hide ID
        },
        # Ensure only the 'Select' column can be edited
        disabled=[col for col in df.columns] 
    )

    # Logic to handle the manual selection
    selected_rows = event[event["Select"] == True]
    
    if not selected_rows.empty:
        # Return the first selected record as a dict (minus the Select col)
        record = selected_rows.drop(columns=["Select"]).iloc[0].to_dict()
        st.session_state["last_selected_name"] = record.get("customer_name")
        return record
    
    st.session_state["last_selected_name"] = None
    return None

# -----------------------------
# Customer Device table
# -----------------------------

@staticmethod
def render_selectable_table(df, key_prefix, id_column_to_hide):
    """
    Renders a standardized table with a checkbox selection column.
    Returns the selected record as a dict or None.
    """
    if df is None or df.empty:
        st.info("No data available to display.")
        return None

    # 1. Prepare Data
    df_with_sel = df.copy()
    df_with_sel.insert(0, "Select", False)

    # 2. Generate unique key based on data content to force refresh on data change
    data_hash = hash(pd.util.hash_pandas_object(df).sum())
    
    # 3. Render Data Editor
    event = st.data_editor(
        df_with_sel,
        key=f"{key_prefix}_{data_hash}",
        use_container_width=True,
        hide_index=True,
        column_config={
            "Select": st.column_config.CheckboxColumn(
                "Select",
                help="Select a record to manage",
                default=False,
            ),
            id_column_to_hide: None  # Hide the primary ID column
        },
        disabled=[col for col in df.columns] # Make all columns except 'Select' read-only
    )

    # 4. Handle Selection Logic
    selected_rows = event[event["Select"] == True]
    
    if not selected_rows.empty:
        # Drop the UI-only 'Select' column before returning data
        record = selected_rows.drop(columns=["Select"]).iloc[0].to_dict()
        return record
    
    return None



def render_device_table(df: pd.DataFrame):
    df["created_at"] = pd.to_datetime(df["created_at"], errors="coerce")
    df["updated_at"] = pd.to_datetime(df["updated_at"], errors="coerce")

    return st.data_editor(
        df,
        use_container_width=True,
        hide_index=True,
        column_order=["device_name", "device_model", "device_role", "planning_status", "lifecycle_status" "updated_at"],
        column_config={
            "device_name": st.column_config.TextColumn("Customer Name", disabled=True),
            "device_role": st.column_config.TextColumn("Account ID", disabled=True),
            "service_model": st.column_config.NumberColumn("Model", format="%d", disabled=True),
            "planning_status": st.column_config.NumberColumn("Planning", format="%d", disabled=True),
            "lifecycle_status": st.column_config.NumberColumn("lifecycle", format="%d", disabled=True),
            "created_at": st.column_config.DatetimeColumn("Created At", format="YYYY-MM-DD HH:mm", disabled=True),
            "updated_at": st.column_config.DatetimeColumn("Updated At", format="YYYY-MM-DD HH:mm", disabled=True),
        },
    )


# -----------------------------
# Generic DataFrame Renderer
# -----------------------------
def render_table(df: pd.DataFrame, title: str):
    st.subheader(title)
    st.dataframe(df, use_container_width=True)

# -----------------------------
# Metric Card Renderer
# -----------------------------
def render_metrics(metrics: dict):
    cols = st.columns(len(metrics))
    for col, (label, value) in zip(cols, metrics.items()):
        col.metric(label, value)

class UI:
    @staticmethod
    def button(label, color="blue", key=None):
        """Enhanced button with custom CSS color support."""
        color_map = {
            "green": "#28a745",
            "red": "#dc3545",
            "amber": "#ffbf00",
            "blue": "#007bff"
        }
        hex_color = color_map.get(color, "#6c757d")

        with stylable_container(
            key=f"container_{key}",
            css_styles=f"""
                button {{
                    background-color: {hex_color} !important;
                    color: white !important;
                    border-radius: 5px;
                }}
            """,
        ):
            return st.button(label, key=key)

    @staticmethod
    def render_selectable_table(df, key_prefix, id_column_to_hide=None):
        """
        Renders a table with a checkbox for selection.
        Strictly enforces a single selection return.
        """
        if df is None or df.empty:
            return None

        # 1. Add 'Select' column for checkbox interaction
        display_df = df.copy()
        display_df.insert(0, "Select", False)

        # 2. Configure Columns
        column_config = {
            "Select": st.column_config.CheckboxColumn(
                "Select", 
                help="Select a single row",
                default=False
            )
        }
        if id_column_to_hide:
            column_config[id_column_to_hide] = None

        # 3. Render Editor
        # Only the 'Select' column is editable
        edited_df = st.data_editor(
            display_df,
            key=f"{key_prefix}_editor",
            column_config=column_config,
            use_container_width=True,
            hide_index=True,
            disabled=[c for c in display_df.columns if c != "Select"]
        )

        # 4. Filter for selected rows
        selected_rows = edited_df[edited_df["Select"] == True]
        
        # 5. SINGLE SELECTION ENFORCEMENT
        if len(selected_rows) > 1:
            st.warning("⚠️ Only one selection is allowed. Using the first selected row.")
            # Optional: You could also return None here to force them to pick one
            return selected_rows.drop(columns=["Select"]).iloc[0].to_dict()
        
        elif len(selected_rows) == 1:
            return selected_rows.drop(columns=["Select"]).iloc[0].to_dict()
        
        return None