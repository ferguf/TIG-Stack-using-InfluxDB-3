import drawsvg as draw
import math

# Internal configuration
W, H = 900, 800
NODE_COLORS = {
    1: "#ef4444", 2: "#f59e0b", 3: "#22c55e", 4: "#3b82f6",
    5: "#ef444480", 6: "#f59e0b80", 7: "#22c55e80", 8: "#3b82f680",
}
SIZE_MAP = {"XS": 1, "S": 2, "M": 4, "L": 6, "XL": 8}
TYPE_MAP = {"solid": None, "dash": "5,5", "double-dash": "2,2"}

def get_pos(radius, angle_deg):
    theta = math.radians(angle_deg - 90)
    return radius * math.cos(theta), radius * math.sin(theta)

def render_node(d, node_id, attrs):
    if not attrs.get("visible", True): return
    nx, ny = (0, 0) if attrs["radius"] == 0 else get_pos(attrs["radius"], attrs["angle"])
    colors = attrs.get("colors", [7, 3])
    outer_color, inner_color = NODE_COLORS.get(colors[0], "#64748b"), NODE_COLORS.get(colors[1], "#0f172a")
    
    d.append(draw.Circle(nx, ny, attrs.get("size_outer", 15), fill=outer_color))
    d.append(draw.Circle(nx, ny, attrs.get("size_inner", 10), fill=inner_color, stroke="black"))
    d.append(draw.Text(attrs.get("label_header", ""), 12, nx, ny + attrs.get("size_outer", 15) + 10, fill="white", text_anchor="middle"))

def render_arc(d, galaxy_nodes, arc):
    n1, n2 = galaxy_nodes[arc["source"]], galaxy_nodes[arc["target"]]
    x1, y1 = get_pos(n1["radius"], n1["angle"])
    x2, y2 = get_pos(n2["radius"], n2["angle"])
    
    p = draw.Path(
        stroke=NODE_COLORS.get(arc.get("colors", [8,4])[0]), 
        stroke_width=SIZE_MAP.get(arc.get("size", "S")), 
        fill="none", 
        stroke_dasharray=TYPE_MAP.get(arc.get("type", "solid"))
    )
    p.M(x1, y1).A(n1["radius"], n1["radius"], 0, 0, 1, x2, y2)
    d.append(p)

def render_galileo(galaxy_nodes, galaxy_arcs, galaxy_links):
    """The Main Entry point for the engine."""
    d = draw.Drawing(W, H, origin="center")
    d.append(draw.Rectangle(-W/2, -H/2, W, H, fill="#1a1a1a")) 
    
    for arc in galaxy_arcs: 
        render_arc(d, galaxy_nodes, arc)
    for node_id, attrs in galaxy_nodes.items(): 
        render_node(d, node_id, attrs)
        
    return d.as_svg()