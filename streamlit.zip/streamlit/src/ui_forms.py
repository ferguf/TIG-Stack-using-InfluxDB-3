import streamlit as st
from src.ui_components import UI

def create_customer_form():
    """Renders the UI for creating a new customer with custom colored buttons."""
    with st.expander("📝 Create New Customer", expanded=True):
        # Using a container with a border instead of st.form
        with st.container(border=True):
            st.markdown("### Customer Details")
            
            # Note: We add keys to inputs to preserve state outside of a form
            name = st.text_input("Customer Name", placeholder="e.g. Acme Corp", key="create_cust_name")
            acc_id = st.text_input("Account ID", placeholder="e.g. ACC-12345", key="create_cust_acc")
            
            st.markdown("---")
            col1, col2, _ = st.columns([1, 1, 3])
            
            with col1:
                # Save button using your UI class (Green)
                if UI.button("Save", color="green", key="save_new_customer"):
                    if name and acc_id:
                        return {"customer_name": name, "account_id": acc_id}
                    else:
                        st.warning("All fields are required.")
            
            with col2:
                # Cancel button using your UI class (Red)
                if UI.button("Cancel", color="red", key="cancel_new_customer"):
                    st.session_state["show_create_form"] = False
                    st.rerun()
                
    return None

def update_customer_form(record):
    """Renders the UI for updating an existing customer with styled buttons."""
    if not record:
        return None

    with st.expander(f"🔄 Editing: {record['account_id']}", expanded=True):
        with st.container(border=True):
            st.markdown("### Update Details")
            
            # Using keys derived from account_id to ensure state uniqueness
            name = st.text_input(
                "Customer Name", 
                value=record.get("customer_name", ""), 
                key=f"upd_name_{record['account_id']}"
            )
            acc_id = st.text_input(
                "Account ID", 
                value=record.get("account_id", ""), 
                disabled=True,
                key=f"upd_acc_{record['account_id']}"
            )
            
            st.markdown("---")
            col1, col2, _ = st.columns([1, 1, 3])
            
            with col1:
                # Save changes is Green
                if UI.button("Save Changes", color="green", key=f"save_upd_{record['account_id']}"):
                    if name:
                        return {"customer_name": name, "account_id": acc_id}
                    else:
                        st.warning("Customer Name cannot be empty.")
            
            with col2:
                # Cancel update is Amber
                if UI.button("Cancel", color="amber", key=f"cancel_upd_{record['account_id']}"):
                    st.session_state["show_update_form"] = False
                    st.rerun()
                    
    return None

def create_fabric_service_form():
    """
    Renders the UI for provisioning a new Fabric Service using container/border 
    style to support custom colored UI buttons.
    """
    with st.expander("🚀 Provision New Fabric Service", expanded=True):
        with st.container(border=True):
            st.markdown("### Service Details")
            
            col1, col2 = st.columns(2)
            with col1:
                name = st.text_input("Service Name*", placeholder="e.g.,Finn tech  L3VPN Prod", key="fab_prov_name")
                s_type = st.selectbox("Service Type", ["IPVPN", "Eline EVPL", "Eline EPL", "EVPLAN","EPLAN", "DIA", "IOD" ], key="fab_prov_type")
            with col2:
                alias = st.text_input("Alias", key="fab_prov_alias")
                rt = st.text_input("Route Target", placeholder="3549:100001", key="fab_prov_rt")
            
            desc = st.text_area("Description", key="fab_prov_desc")
            
            st.markdown("---")
            col1, col2, _ = st.columns([1, 1, 3])
            
            with col1:
                # Save/Launch button (Green)
                if UI.button("Create Fabric Service", color="green", key="btn_confirm_launch_fab"):
                    if name:
                        return {
                            "service_name": name,
                            "service_type": s_type,
                            "service_alias": alias,
                            "route_target": rt,
                            "service_description": desc,
                            "health_status": 4
                        }
                    else:
                        st.warning("Service Name is required.")
            
            with col2:
                # Cancel button (Red)
                if UI.button("Cancel", color="red", key="btn_cancel_launch_fab"):
                    st.session_state["fab_show_provision"] = False
                    st.rerun()
                    
    return None

def update_fabric_service_form(record):
    """Simple UI for updating an existing Fabric Service."""
    sid = record.get("service_id")
    
    with st.expander(f"⚙️ Edit {record.get('service_name')}", expanded=True):
        with st.container(border=True):
            # Fields
            new_name = st.text_input("Service Name*", value=record.get("service_name", ""), key=f"un_{sid}")
            new_alias = st.text_input("Alias", value=record.get("service_alias", ""), key=f"ua_{sid}")
            new_rt = st.text_input("Route Target", value=record.get("route_target", ""), key=f"urt_{sid}")
            new_desc = st.text_area("Description", value=record.get("service_description", ""), key=f"ud_{sid}")
            
            # Simple 0-4 Slider
            new_health = st.slider("Health Metric", 0, 4, value=int(record.get("health_status", 4)), key=f"uh_{sid}")

            st.markdown("---")
            col1, col2, _ = st.columns([1, 1, 3])
            
            with col1:
                if UI.button("Update", color="green", key=f"bs_{sid}"):
                    if new_name:
                        return {
                            "service_name": new_name,
                            "service_type": record.get("service_type"),
                            "service_alias": new_alias,
                            "route_target": new_rt,
                            "service_description": new_desc,
                            "health_status": int(4)
                        }
                    else:
                        st.warning("Name is required.")
            
            with col2:
                if UI.button("Cancel", color="red", key=f"bc_{sid}"):
                    st.session_state["fs_show_update"] = False
                    st.rerun()
    return None