import streamlit as st

class FabricStateManager:
    """Handles session state for Fabric Services to ensure UI sync."""


    @staticmethod
    def initialize():
        # Using 'fs_' prefix to distinguish Fabric Service from other state
        keys = {
            "fs_active_record": None,
            "fs_active_id": None,
            "fs_show_update": False,
            "fs_confirm_delete": False
        }
        for key, default in keys.items():
            if key not in st.session_state:
                st.session_state[key] = default


    @staticmethod
    def sync_selection(selection):
        # selection is now either a dict or None
        new_id = selection.get("service_id") if selection else None
        old_id = st.session_state.get("fs_active_id")

        if new_id != old_id:
            st.session_state["fs_active_id"] = new_id
            st.session_state["fs_active_record"] = selection
            # ... rest of your reset logic ...
            return True
        return False

    @staticmethod
    def get_active_record():
        return st.session_state.get("fs_active_record")

    @staticmethod
    def get_active_id():
        return st.session_state.get("active_fab_id")
