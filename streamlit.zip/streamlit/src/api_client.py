# api_client.py
import uuid
import requests
import pandas as pd
from typing import Optional
import streamlit as st

API_URL = "http://fastapi:8000"


# ----------------------------------------------------------------------
# CRUD Cusotmers Services  
# ----------------------------------------------------------------------
def get_customers() -> pd.DataFrame:
    """Fetch all customers from FastAPI and return as DataFrame."""
    resp = requests.get(f"{API_URL}/customers/")
    resp.raise_for_status()
    data = resp.json()
    return pd.DataFrame(data if isinstance(data, list) else [data])

def post_customer(customer_name: str, account_id: str) -> dict:
    """
    Create a new customer via FastAPI.
    Returns the created customer record as a dict.
    """
    payload = {
        "customer_name": customer_name,
        "account_id": account_id,
    }
    resp = requests.post(f"{API_URL}/customers/", json=payload)
    resp.raise_for_status()
    return resp.json()

def update_customer(customer_id: str, account_id: str, customer_name: str) -> dict:
    """
    Update a customer via FastAPI.
    """
    # The payload needs to match your CURL structure
    payload = {
        "customer_id": customer_id,  # Added this back in per your CURL example
        "customer_name": customer_name,
        "account_id": account_id,
    }
    
    # Note: Remove the trailing slash after {customer_id} if your FastAPI route 
    # doesn't use it, as seen in your CURL '.../customers/uuid'
    resp = requests.put(f"{API_URL}/customers/{customer_id}", json=payload)
    resp.raise_for_status()
    return resp.json()

def delete_customer(customer_id: uuid) -> dict:
    """
    Delete a customer by Name via FastAPI.
    Returns the API response (often a confirmation message).
    """
    resp = requests.delete(f"{API_URL}/customers/{customer_id}")
    resp.raise_for_status()
    return resp.json()

# ----------------------------------------------------------------------
# CRUD Fabric Services  
# ----------------------------------------------------------------------

def get_fabric_services(customer_id: str) -> pd.DataFrame:
    """Fetch fabric services and return as a scannable DataFrame."""
    try:
        url = f"{API_URL}/fabric_services/customer/{customer_id}"
        resp = requests.get(url)
        
        if resp.status_code == 404:
            return pd.DataFrame()
            
        resp.raise_for_status()
        data = resp.json()
        
        if not data:
            return pd.DataFrame()
            
        return pd.DataFrame(data if isinstance(data, list) else [data])
    except Exception as e:
        print(f"Error fetching fabric services: {e}")
        return pd.DataFrame()

def update_fabric_service(service_id: str, payload: dict) -> dict:
    """
    Updates a fabric service using PUT. 
    Matches the required structure: http://fastapi:8000/fabric_services/{id}
    """
    try:
        url = f"{API_URL}/fabric_services/{service_id}"
        # Payload must include all fields required by the FastAPI model
        resp = requests.put(url, json=payload)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.HTTPError as e:
        # Logs the specific 405 or 422 error for easier debugging
        print(f"Update API Error: {e.response.text}")
        raise e

def delete_fabric_service(service_id: str) -> bool:
    """
    Deletes a fabric service using DELETE.
    """
    try:
        url = f"{API_URL}/fabric_services/{service_id}"
        resp = requests.delete(url)
        resp.raise_for_status()
        return True
    except Exception as e:
        print(f"Delete API Error: {e}")
        raise e

def post_fabric_service(payload: dict) -> dict:
    """Create a new fabric service via FastAPI."""
    try:
        url = f"{API_URL}/fabric_services/"
        resp = requests.post(url, json=payload)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"Post API Error: {e}")
        raise e


# ----------------------------------------------------------------------
# # CRUD Fabric Connections  
# ----------------------------------------------------------------------


def get_fabric_connections() -> pd.DataFrame:
    resp = requests.get(f"{API_URL}/fabric_connections/")
    resp.raise_for_status()
    data = resp.json()
    return pd.DataFrame(data if isinstance(data, list) else [data])


# ----------------------------------------------------------------------
# # CRUD Fabric ports  
# ----------------------------------------------------------------------


def get_devices() -> pd.DataFrame:
    resp = requests.get(f"{API_URL}/devices/")
    resp.raise_for_status()
    data = resp.json()
    return pd.DataFrame(data if isinstance(data, list) else [data])


def post_device(
    device_name: str,
    location: str,
    device_role: str,
    device_model: Optional[str] = None,
    device_vendor: Optional[str] = None,
    serial_number: Optional[str] = None,
    availability_zone: Optional[str] = "Zone 0",
    lifecycle_status: Optional[str] = "Active",
    planning_status: Optional[str] = "Planned",
    health_status: Optional[int] = 4,
    device_description: Optional[str] = None,

):
    payload = {
        "device_name": device_name,
        "location": location,
        "device_role": device_role,
        "device_vendor": device_vendor,
        "device_model": device_model,
        "planning_status": planning_status,
        "serial_number": serial_number,
        "device_description": device_description,
        "health_status": health_status,
    }
    payload = {k: v for k, v in payload.items() if v is not None}
    st.write("Payload being sent:", payload)

    response = requests.post(f"{API_URL}/devices/", json=payload)
    response.raise_for_status()
    return response.json()


